Modified version of USBaspLoader.2010-07-27 for metaboard.
Changes are the following:

1. Change bootloader pin from PD7 to PC2.
2. Bootloader do not exit after complete loading of user codes.